<?php
$host = "localhost";
$dbname = "blogger_bkash";
$user = "root";
$pass = "";

try{
    $dbh = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8",$user,$pass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die("Database connection failed: ".$e->getMessage());
}
?>