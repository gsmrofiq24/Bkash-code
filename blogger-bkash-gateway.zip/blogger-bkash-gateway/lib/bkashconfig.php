<?php
if(!isset($_SESSION)) session_start();

define("BASEURL", "https://tokenized.pay.bka.sh/v1.2.0-beta"); // Live
define("APPKEY", "Z9YviKKL6S8xMDMZNXe89bUZtc");
define("APPSECRET", "9di6mVkVP5khpBIPBDHBisCoQTsMNkHZf4qbfXQ0UWukWp9GropJ");
define("USERNAME", "01810794157"); // Live username
define("PASSWORD", "=wSd0z7?Uzf"); // Live password
define("CALLBACK", "https://localhost:8080/lib/execute-payment.php"); // Update this
?>