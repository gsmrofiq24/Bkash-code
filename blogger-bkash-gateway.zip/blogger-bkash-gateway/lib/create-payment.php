<?php
include_once __DIR__ . "/bkashconfig.php";
include_once "../includes/db.php";

if(!isset($_SESSION['id_token']) || empty($_SESSION['id_token'])){
    die(json_encode(['error'=>"Missing id_token"]));
}

$amount = $_POST['amount'] ?? 0;
if(!is_numeric($amount) || $amount <= 0){
    die(json_encode(['error'=>"Invalid amount"]));
}

$requestbody = [
    'mode' => '0011',
    'amount' => $amount,
    'currency' => 'BDT',
    'intent' => 'sale',
    'payerReference' => 'blogger_user',
    'merchantInvoiceNumber' => random_int(1000000,9999999),
    'callbackURL' => CALLBACK
];

$ch = curl_init(BASEURL."/tokenized/checkout/create");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($requestbody),
    CURLOPT_HTTPHEADER => [
        "Authorization: ".$_SESSION['id_token'],
        "X-APP-Key: ".APPKEY,
        "accept: application/json",
        "content-type: application/json"
    ],
]);

$response = curl_exec($ch);
curl_close($ch);
$response = json_decode($response,true);

if(isset($response['bkashURL'])){
    echo $response['bkashURL'];
}else{
    echo json_encode($response);
}
?>