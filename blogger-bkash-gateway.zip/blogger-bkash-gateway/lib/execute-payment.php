<?php
include_once __DIR__ . "/bkashconfig.php";
include_once "../includes/db.php";

$paymentID = $_GET['paymentID'] ?? '';
$status = $_GET['status'] ?? '';

if(empty($paymentID)){
    die("Payment ID missing");
}

// Cancelled Payment
if($status === 'cancel'){
    $stmt = $dbh->prepare("INSERT INTO payments(paymentID,trxID,amount,email,status) VALUES(:paymentID,:trxID,:amount,:email,:status)");
    $stmt->execute([
        ':paymentID'=>$paymentID,
        ':trxID'=>'N/A',
        ':amount'=>0,
        ':email'=>'guest@example.com',
        ':status'=>'cancel'
    ]);

    echo "<h2>Payment Cancelled!</h2>";
    echo "<p>আপনি পেমেন্ট বাতিল করেছেন। পুনরায় চেষ্টা করতে পারেন।</p>";
    echo "<a href='../index.html'>Try Again</a>";
    exit;
}

// Execute Payment
$ch = curl_init(BASEURL."/tokenized/checkout/execute");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode(['paymentID'=>$paymentID]),
    CURLOPT_HTTPHEADER => [
        "Authorization: ".$_SESSION['id_token'],
        "X-APP-Key: ".APPKEY,
        "accept: application/json",
        "content-type: application/json"
    ],
]);

$result = curl_exec($ch);
curl_close($ch);
$response = json_decode($result,true);

// Success
if($response['statusMessage']==='Successful' && $response['transactionStatus']==='Completed'){
    $stmt = $dbh->prepare("INSERT INTO payments(paymentID,trxID,amount,email,status) VALUES(:paymentID,:trxID,:amount,:email,:status)");
    $stmt->execute([
        ':paymentID'=>$response['paymentID'],
        ':trxID'=>$response['trxID'],
        ':amount'=>$response['amount'],
        ':email'=>'guest@example.com',
        ':status'=>'success'
    ]);

    // Random Download File
    $files = glob('../downloads/*'); 
    $randomFile = basename($files[array_rand($files)]);
    header("Location: ../downloads/$randomFile");
    exit;

// Failed Payment
}else{
    $stmt = $dbh->prepare("INSERT INTO payments(paymentID,trxID,amount,email,status) VALUES(:paymentID,:trxID,:amount,:email,:status)");
    $stmt->execute([
        ':paymentID'=>$response['paymentID'] ?? 'N/A',
        ':trxID'=>$response['trxID'] ?? 'N/A',
        ':amount'=>$response['amount'] ?? 0,
        ':email'=>'guest@example.com',
        ':status'=>'failed'
    ]);

    echo "<h2>Payment Failed!</h2>";
    echo "<p>আপনার payment সম্পন্ন হয়নি। অনুগ্রহ করে আবার চেষ্টা করুন।</p>";
    echo "<a href='../index.html'>Try Again</a>";
    exit;
}
?>