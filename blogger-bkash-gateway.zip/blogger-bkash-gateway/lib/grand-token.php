<?php
include_once __DIR__ . "/bkashconfig.php";

$post_token = json_encode([
    'app_key' => APPKEY,
    'app_secret' => APPSECRET
]);

$ch = curl_init(BASEURL."/tokenized/checkout/token/grant");

$headers = [
    "Content-Type: application/json",
    "username: ".USERNAME,
    "password: ".PASSWORD
];

curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $post_token,
    CURLOPT_RETURNTRANSFER => true
]);

$result = curl_exec($ch);
curl_close($ch);

$response = json_decode($result,true);

if(isset($response['id_token'])){
    $_SESSION['id_token'] = $response['id_token'];
    echo json_encode(['success'=>true,'id_token'=>$_SESSION['id_token']]);
}else{
    echo json_encode(['success'=>false,'response'=>$response]);
}
?>